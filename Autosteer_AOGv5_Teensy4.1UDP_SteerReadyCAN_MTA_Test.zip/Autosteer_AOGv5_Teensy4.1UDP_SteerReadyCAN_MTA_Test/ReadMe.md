*Version 31.12.2022*  
- Updated with v5.6 features  

Update 31.12.2022  
- GPS options added to serial monitor service tool  
